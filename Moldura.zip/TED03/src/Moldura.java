
public class Moldura {

	public static void main(String[] args) {
		
		int b=30;
		int h=10;
		int h2=26;
		int b2=6;
		int Amaior = b*h;
		int Amenor = b2*h2;
		int AreaDaMoldura = Amaior-Amenor;
	
		System.out.println("Primeiro ret�ngulo: " +Amaior);
		System.out.println("Segundo ret�ngulo: " +Amenor);
		System.out.println("A �rea da moldade �: " +AreaDaMoldura);
		
		
		

	}

}
