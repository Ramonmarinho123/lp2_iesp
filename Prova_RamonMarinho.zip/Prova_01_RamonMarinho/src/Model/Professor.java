package Model;

public class Professor {
	
	private String nomeProf;
	private String matriculaProf;
	private String disciplina;
	private String coordenacao;
	
	
		public Professor(String nomeProf, String matriculaProf, String disciplina, String coordenacao) {
		
		this.nomeProf = nomeProf;
		this.matriculaProf = matriculaProf;
		this.disciplina = disciplina;
		this.coordenacao = coordenacao;
		
	}
		public String info (){
			String saida="Nome:"+this.nomeProf+
					     "\nMatr�culo:"+this.matriculaProf+
					     "\nDisciplina:"+this.disciplina+
					     "\nCoordenacao:"+this.coordenacao;
			return saida;
		}



}	