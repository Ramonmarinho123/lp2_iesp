package Model;

public class Turma {

	private Aluno aluno1;
	private Aluno aluno2;
	private Aluno aluno3;
	private Professor professor;

	public Turma(Aluno aluno1, Aluno aluno2, Aluno aluno3, Professor professor) {
		this.aluno1 = aluno1;
		this.aluno2 = aluno2;
		this.aluno3 = aluno3;
		this.professor = professor;
	}

	public String info() {
		String saida = "Primeiro Aluno:" + this.aluno1 + "Segundo Aluno:" + this.aluno2 + "Terceiro Aluno:"
				+ this.aluno3 + "\nProfessor:" + this.professor;
		return saida;
	}

	public String verificaMaiorCre() {

		if (aluno1.getCre() > aluno2.getCre() && aluno1.getCre() > aluno3.getCre())
			return aluno1.getNomeAluno();

		if (aluno2.getCre() > aluno1.getCre() && aluno2.getCre() > aluno3.getCre())
			return aluno2.getNomeAluno();

		if (aluno3.getCre() > aluno2.getCre() && aluno3.getCre() > aluno1.getCre())
			return aluno3.getNomeAluno();

		else
			return "Cre's iguais";

	}
	

	public boolean PresencaAluno(String nomeAluno) {

		if (nomeAluno == aluno1.getNomeAluno())
			return true;
		
		if (nomeAluno == aluno2.getNomeAluno())
			return true;
				
		if (nomeAluno == aluno3.getNomeAluno())
			return true;
		
		
		else
			return false;
	}
	

}
