package Model;

public class Aluno {

	private String nomeAluno;
	private String matriculaAluno;
	private String curso;
	private double cre;
	private boolean alunoPresente;

	// Cosntrutores

	public Aluno(String nomenomeAluno, String matriculaAluno, String curso, double cre) {

		this.nomeAluno = nomenomeAluno;
		this.matriculaAluno = matriculaAluno;
		this.curso = curso;
		this.cre = cre;
		
	}

	public String info() {
		String saida = "Nome:" + this.nomeAluno + "\nMatr�culo:" + this.matriculaAluno + "\nCurso:" + this.curso
				+ "\ncre:" + this.cre;

		return saida;
	}


	public String getNomeAluno() {
		return nomeAluno;
	}

	public void setNomeAluno(String nomeAluno) {
		this.nomeAluno = nomeAluno;
	}

	public String getMatriculaAluno() {
		return matriculaAluno;
	}

	public void setMatriculaAluno(String matriculaAluno) {
		this.matriculaAluno = matriculaAluno;
	}

	public String getCurso() {
		return curso;
	}

	public void setCurso(String curso) {
		this.curso = curso;
	}

	public double getCre() {
		return cre;
	}

	public void setCre(double cre) {
		this.cre = cre;
	}

	public boolean isAlunoPresente() {
		return alunoPresente;
	}

	public void setAlunoPresente(boolean alunoPresente) {
		this.alunoPresente = alunoPresente;
	}

}
