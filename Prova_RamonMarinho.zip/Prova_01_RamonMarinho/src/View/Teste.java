package View;

import Model.Aluno;
import Model.Professor;
import Model.Turma;


public class Teste {


public static void main(String[] args) {
		
		
		Aluno PresentenaSala;
		
		Aluno aluno1 = new Aluno("Ramom Marinho", "20214459", "Sistemas para Internet", 9.5);	
		Aluno aluno2 = new Aluno("Raul Marinho", "20214458", "Sistemas para Internet", 9.0);
		Aluno aluno3 = new Aluno("Romario Marinho", "20214457", "Sistemas para Internet", 9.0);
		Professor professor1 = new Professor("Antonio carlos", "20194456", "Java_OO", "Alana");
		
		Turma turma = new Turma (aluno1, aluno2, aluno3, professor1);
		
		System.out.println("NOME DOS ALUNOS\n");
		System.out.println(aluno1.info());
		System.out.println("O aluno est� presente? "+turma.PresencaAluno("Ramom Marinho"));
		System.out.println("-=-=-=-=-=-=-=-=-=-=-=-=");
		System.out.println(aluno2.info());
		System.out.println("O aluno est� presente? "+turma.PresencaAluno(""));
		System.out.println("-=-=-=-=-=-=-=-=-=-=-=-=");
		System.out.println(aluno3.info());
		System.out.println("O aluno est� presente? "+turma.PresencaAluno(""));
		System.out.println("-=-=-=-=-=-=-=-=-=-=-=-=");
		System.out.println("\nNOME DO PROFESSOR\n");
		System.out.println(professor1.info());
		System.out.print("Maior cre da turma: " + turma.verificaMaiorCre());
		
		
				   	
	}

}
