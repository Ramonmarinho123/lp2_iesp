package or.Aula03;

import java.util.Scanner;
public class Lutador {

	public static void main(String[] args) {
		Scanner lutador=new Scanner(System.in);
		
		String Nome;
		Double Peso;
		
		System.out.println("Informe o nome do lutador: ");
		Nome=lutador.nextLine();
		
		System.out.println("Informe o peso do lutador: ");
		Peso=lutador.nextDouble();
		
	     if(Peso< 65){
	     System.out.printf("\nO lutador " + Nome +" pesa " + Peso +" e se enquadra na categoria Pena.");}
	     else if(Peso >=65 && Peso <72){
	     System.out.printf("\nO lutador " + Nome +" pesa " + Peso +" e se enquadra na categoria Leve.");}
	     else if(Peso >=72 && Peso <79){
	     System.out.printf("\nO lutador " + Nome +" pesa " + Peso +" e se enquadra na categoria Ligeiro.");}
	     else if(Peso >=79 && Peso <86){
		 System.out.printf("\nO lutador " + Nome +" pesa " + Peso +" e se enquadra na categoria Meio-m�dio.");}
	     else if(Peso >=89 && Peso <93){
		 System.out.printf("\nO lutador " + Nome +" pesa " + Peso +" e se enquadra na categoria M�dio.");}
	     else if(Peso >=93 && Peso <100){
		 System.out.printf("\nO lutador " + Nome +" pesa " + Peso +" e se enquadra na categoria Meio-pesado.");}
	     else {
	     System.out.printf("\nO lutador " + Nome +" pesa " + Peso +" e se enquadra na categoria Pesado."); 
	     }

	}

}
