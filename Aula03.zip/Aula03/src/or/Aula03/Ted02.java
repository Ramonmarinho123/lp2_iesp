package or.Aula03;

import java.util.Scanner;
public class Ted02 {

	public static void main(String[] args) {
		Scanner ler = new Scanner(System.in);
		
		double l1,l2,l3;
		
		System.out.println("informe o lado um: ");
		l1=ler.nextDouble();
		
		System.out.println("informe o lado dois: ");
		l2=ler.nextDouble();
		
		System.out.println("informe o lado dois: ");
		l3=ler.nextDouble();
		
		 if (l1 > (l2 + l3) || l2 > (l1 + l3) || l3 > (l1 + l2)){
		      System.out.println("N�o pode ser um triangulo");
		    }
		 else if(l1 == l2 && l1 == l3){
		      System.out.println("O tri�ngulo � Equilatero");
		    }
		 else if(l1 == l2 || l1 == l3 || l2 == l3){
		      System.out.println("O tri�ngulo � Is�sceles");
		    }
		 else{
		      System.out.println("O tri�ngulo � escaleno");
		    } 
	    
			



	}

}
